public final class Color {
    final int red;
    final int green;
    final int blue;

    // constructor
    public Color(int r, int g, int b) {
	red   = r;
	green = g;
	blue  = b;
    }
}
