public final class Complex {
    // x+yi 
    final double x;    
    final double y;    

    // constructor 
    public Complex(double x0, double y0) {
	x = x0;
	y = y0;
    }
}
