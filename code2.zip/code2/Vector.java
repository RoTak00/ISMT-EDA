// a 3d vector 
public class Vector {
    // coordinates
    final double x;
    final double y; 
    final double z;

    // constructor 
    public Vector(double x0, double y0, double z0 ) {
	x = x0;
	y = y0;
	z = z0;
    }
}
